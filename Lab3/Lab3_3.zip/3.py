import random
from collections import Counter
from itertools import combinations
import copy
import operator
import sys

class State:
    """
    Class model to represent a state.
    """
    def __init__(self,vector):
        self.vector = vector
        self.parent = None
        self.heuristic = None
        self.memory = None

    def __eq__(self, other):
        if not isinstance(other, State):
            return NotImplemented
        return self.vector == other.vector

def getnegation(literal):
    """
    function to get negation of any literal
    """
    if literal == 'a':
        return '~a'
    elif literal == '~a':
        return 'a'
    elif literal == 'b':
        return '~b'
    elif literal == '~b':
        return 'b'
    elif literal == 'c':
        return '~c'
    elif literal == '~c':
        return 'c'
    elif literal == '~d':
        return 'd'
    elif literal == 'd':
        return '~d'

def check_tautology(clause):
    for literal in clause:
        if getnegation(literal) in clause: #if negation of any literal is present then it is tautology
            return True
    return False

def check_duplicate(clause):
    for f in formula:
        if Counter(clause) == Counter(f): #check if this clause is already present in the formula
            return True
    return False

def invert(bit):
    if bit == 1:
        return 0
    else:
        return 1

def getdict(vector):  # map the literals to its value
    dict = {}
    dict['a'] = vector[0]
    dict['~a'] = invert(vector[0])
    dict['b'] = vector[1]
    dict['~b'] = invert(vector[1])
    dict['c'] = vector[2]
    dict['~c'] = invert(vector[2])
    dict['d'] = vector[3]
    dict['~d'] = invert(vector[3])
    return dict

def heuristic(state): # heuristic for number of clauses satisfied
    dict = getdict(state.vector)
    result = 0
    for clause in formula:
        result += dict[clause[0]] or dict[clause[1]] or dict[clause[2]]
    return result

def GoalTest(state):
    if state.heuristic == clauses: # goal state when heuristic is equal to number of clauses
        return True
    return False

def MoveGen(node,r,tt=None):
    if tt:
        neighbours = []
        index_list = [0,1,2,3]
        comb = combinations(index_list,r) # choose r number from the index list for perturbation
        for combination in list(comb):
            new_state = copy.deepcopy(node) # create a copy
            for index in combination:
                if new_state.memory[index] == 0: # only invert if memory value is zero
                    new_state.vector[index] = invert(new_state.vector[index]) # invert that choosen bit
                    new_state.memory[index] = tt # set the tt value in memory
                    for i in [item for item in index_list if item not in [index]]:
                        new_state.memory[i] = max(0,new_state.memory[i]-1) # decrease other tt value in memory
                    neighbours.append(new_state)
        return neighbours
    neighbours = []
    index_list = [0,1,2,3]
    comb = combinations(index_list,r) # choose r number from the index list for perturbation
    for combination in list(comb):
        new_state = copy.deepcopy(node) # create a copy
        for index in combination:
            new_state.vector[index] = invert(new_state.vector[index]) # invert that choosen bit
        neighbours.append(new_state)
    return neighbours

def notVisited(state,explored,open):
    for s in explored:# check in explored
        if s.vector == state.vector:
            return False
    for s in open: # check in open
        if s.vector == state.vector:
            return False
    return True # return true if not visited

def notVisitedTabu(state,explored):
    for s in explored:# check in explored
        if s.vector == state.vector:
            return False
    return True

def getPath(path,state):
    path.append(state.vector)
    if state.parent == None:#base case
        return
    else:
        getPath(path,state.parent)# recursively find path

def notexplored(state,explored):
    for s in explored:# check in explored
        if s.vector == state.vector:
            return False
    return True

def beam(initial_state,width):
    initial_state.heuristic = heuristic(initial_state)
    open = [initial_state] # initiale open list with initial state
    explored = []
    while open:
        temp = []
        for node in open: #explored width number of node in open
            explored.append(node)
            if GoalTest(node): # check for goal state
                path = []
                getPath(path,node)
                out.write("No. of state in path: "+str(len(path))+"\n")
                out.write("No. of explored state: "+str(len(explored))+"\n")
                for i in reversed(path):
                    out.write(str(i)+"\n")
                return True
            neighbours = MoveGen(node,1) # get neighbours, r = 1 (perturb only 1 bit)
            for neighbour in neighbours:
                if notVisited(neighbour,explored,open): # if not explored
                    neighbour.heuristic = heuristic(neighbour)
                    neighbour.parent = node
                    temp.append(neighbour) # store all neighbour in temp
        curr = open[0]
        open.clear()
        open = open + temp  #append temp to open
        open.sort(key = operator.attrgetter('heuristic'),reverse=True) #  then sort the list using heuristic value
        open = open[:width] # keep only width number of nodes
        if len(open)==0: # boundary case when width is zero
            out.write("width is zero")
            return False
        if curr.heuristic >= open[0].heuristic: # when stuck in local maxima
            path = []
            getPath(path,curr)
            out.write("No. of state in path: "+str(len(path))+"\n")
            out.write("No. of explored state: "+str(len(explored))+"\n")
            for i in reversed(path):
                out.write(str(i)+"\n")
            out.write("stuck in local maxima")
            return False
    return False

def tabu(initial_state,tt):
    initial_state.heuristic = heuristic(initial_state)
    initial_state.memory = [0,0,0,0] # initialize the memory vector
    next=initial_state # start the next state as initial state
    explored = []
    while True:
        explored.append(next)
        if GoalTest(next): # check for goal state
            path = []
            getPath(path,next) # get path
            out.write("No. of state in path: "+str(len(path))+"\n")
            out.write("No. of explored state: "+str(len(explored))+"\n")
            for i in reversed(path):
                out.write(str(i)+"\n")
            return True
        curr = next
        max = 0
        neighbours = MoveGen(curr,1,tt)  # find neighbour, r = 1 (perturb only 1 bit)
        for neighbour in neighbours:
            if notVisitedTabu(neighbour,explored):
                neighbour.parent = curr
                neighbour.heuristic = heuristic(neighbour)
                if neighbour.heuristic >= max: # set next state who has maximum heuristic
                    max = neighbour.heuristic
                    next = neighbour
        if not neighbours: #when all the neighbour are disallowed. Try reducing the tabu tenure value
            path = []
            getPath(path,next)
            out.write("No. of state in path: "+str(len(path))+"\n")
            out.write("No. of explored state: "+str(len(explored))+"\n")
            for i in reversed(path):
                out.write(str(i)+"\n")
            out.write("All neighbour are barred. Try reducing the tt value")
            return False
    return False

def vnd(initial_state):
    initial_state.heuristic = heuristic(initial_state)# calculate heuristic
    next_state=[initial_state]
    local_maxima = False
    r = 1 # simplest neighbourhood function (to perturb only 1 bit)
    while True:
        state = next_state[-1]
        if GoalTest(state):# check for goal state
            path=[]
            getPath(path,state)
            out.write("No. of state in path: "+str(len(path))+"\n")
            out.write("No. of explored state: "+str(len(next_state))+"\n")
            for i in reversed(path):
                out.write(str(i)+"\n")
            return True
        max = state
        for neighbour in MoveGen(state,r):# find neighbours
            neighbour.parent = state
            neighbour.heuristic = heuristic(neighbour)
            if neighbour.heuristic > max.heuristic:
                max = neighbour
        if notexplored(max,next_state):
            next_state.append(max) # set maximum heuristic valued state
        if max == state:
            r = min(4,r+1) # set denser neighbourhood function
    return False

literals = 4
clauses = 5
possible_literals = ['a','~a','b','~b','c','~c','d','~d']
formula = []
for clause in range(clauses):
    rejected = True
    while(rejected):
        random_clause = [random.choice(possible_literals) for i in range(3)] #randomly generate clause
        if (not check_tautology(random_clause)) and (not check_duplicate(random_clause) and (len(set(random_clause)) == len(random_clause))): # check if it is allowed
            rejected = False
    formula.append(random_clause)

formula_file = open("formula.txt","w")
for clause in formula:
    formula_file.write(str(clause)+'\n') # write the formula in file


out = open("output.txt","w")
initial_state = State([0,0,0,0]) #initial state
algo_code = int(sys.argv[1])
if algo_code == 0:
    vnd(initial_state)
elif algo_code == 1:
    beam(initial_state,2) # second argument is beam width
elif algo_code == 2:
    tabu(initial_state,2) # second argument is tt value
