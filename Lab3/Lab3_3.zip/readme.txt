run the following command

$python 3.py <Algo_code>

command line argument is algo code: '0' for VND, '1' for beam search, '2' for tabu search
Ex: python 3.py 0

Output file format:
	length of path
	number of explored state
	<path finded by algorithm (last state in path is solution unless it is stuck)>

*formula.txt file contains the randomly generated formula