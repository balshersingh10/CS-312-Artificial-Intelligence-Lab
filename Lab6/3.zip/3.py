import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

#read data
data = pd.read_csv("spambase.data",header=None)
#seperate x and y
x = data.drop([57],axis='columns')
y = data.iloc[:,-1]
#split test and train test
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3)
#define and train model
model = SVC(C=100,kernel="linear") # for different kernel and C value change argument
model.fit(x_train,y_train)
#get prediction on test dataset
model.score(x_test,y_test)
