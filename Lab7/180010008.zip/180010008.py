import numpy as np

def left_move(decision):
    Dect = {
    'N':'W',
    'S':'E',
    'W':'S',
    'E':'N'
    }
    return Dect.get(decision,"Invalid decision")

def right_move(decision):
    Dect = {
    'N':'E',
    'S':'W',
    'W':'N',
    'E':'S'
    }
    return Dect.get(decision,"Invalid decision")

def STF(p,q,decision):
    if p==0 and q==4:
        return [(p,q,0,0)]
    elif p==1 and q==4:
        return [(p,q,0,0)]
    else:
        state_probs = []
        for a in [decision,left_move(decision),right_move(decision)]:
            next_p,next_q = p,q
            if(a=='N' and p-1 >=0):
                next_p = p-1
            elif(a=='S' and p+1 <=3):
                next_p = p+1
            else:
                next_p = p

            if(a=='W' and q-1 >=0):
                next_q = q-1
            elif(a=='E' and q+1 <= 4):
                next_q = q+1
            else:
                next_q = q
            if next_p==2 and next_q==1:
                next_p=p
                next_q=q
            if(a==decision):
                prob = 0.8
            else:
                prob = 0.1
            utility = np.transpose(Rewards)[next_p][next_q]
            state_probs.append((next_p,next_q,prob,utility))
        return state_probs

def value_itr(Policy,gamma,Value_function):
    diff = 0.19
    while(diff>0.01):
        for q in [0,1,2,3,4]:
            for p in [0,1,2,3]:
                prev_Value_function = np.copy(Value_function)
                Val_action_prob=[]
                for decision in ['N','S','W','E']:
                    SOSS = 0.0
                    transition_temp = STF(p,q,decision)
                    for next_p,next_q, prob, utility in transition_temp:
                        SOSS = SOSS + prob*(utility+gamma*Value_function[next_p][next_q])
                    Val_action_prob.append(SOSS)
                Value_function[p][q] = max(Val_action_prob)
        diff = np.max(np.absolute(prev_Value_function-Value_function))
    for q in [0,1,2,3,4]:
        for p in [0,1,2,3]:
            Val_action_prob = []
            for decision in ['N','S','W','E']:
                SOSS = 0.0
                transtition_temp = STF(p,q,decision)
                for next_p,next_q, prob, utility in transtition_temp:
                    SOSS = SOSS + prob*(utility+gamma*Value_function[next_p][next_q])
                Val_action_prob.append(SOSS)
            max_value = max(Val_action_prob)
            count = 0
            index = 0
            for value in (Val_action_prob):
                if value == max_value:
                    count+=1
                    Policy[p][q][index] = 1.0
                else:
                    Policy[p][q][index] = 0.0
                index = index + 1
            Policy[p][q] = Policy[p][q]/count
    return Value_function,Policy

def policy_itr(Policy,gamma,Value_function):
    flag = 1
    iteration = 0
    while(flag):
        diff = 0.19
        while(diff > 0.01):
            prev_Value_function = np.copy(Value_function)
            for q in [0,1,2,3,4]:
                for p in [0,1,2,3]:
                    SOA = 0
                    for ii,decision in enumerate(['N','S','W','E']):
                        SOS = 0.0
                        transition_temp = STF(p,q,decision)
                        for new_p,new_q, prob, utility in transition_temp:
                            SOS = SOS + prob*(utility+gamma*(prev_Value_function[new_p][new_q]))
                        SOA = SOA + Policy[p][q][ii]*SOS
                    Value_function[p][q] = SOA
                    temp = diff
            diff = np.max(np.absolute(prev_Value_function-Value_function))
        Prev_action = np.copy(Policy)
        for q in [0,1,2,3,4]:
            for p in [0,1,2,3]:
                Val_action_prob = []
                for decision in ['N','S','W','E']:
                    SOSS = 0.0
                    transition_temp = STF(p,q,decision)
                    for next_p,next_q, prob, utility in transition_temp:
                        SOSS = SOSS + prob*(utility+gamma*Value_function[next_p][next_q])
                    Val_action_prob.append(SOSS)
                max_value = max(Val_action_prob)
                count = 0
                index = 0
                for value in (Val_action_prob):
                    if value == max_value:
                        count+=1
                        Policy[p][q][index] = 1.0
                    else:
                        Policy[p][q][index] = 0.0
                    index = index + 1
                Policy[p][q] = Policy[p][q]/count
        if (Prev_action == Policy).all():
            flag = 0
        iteration = iteration + 1
    return Value_function,Policy

shape = (4,5,4)
init_prob = 0.25
Gamma = 0.9
Rewards = np.array([[-1,-1,-1,-1],[-1,-1,-9999,-1],[-1,-1,-1,-1],[-1,-1,-1,-1],[+10,-200,-1,-1]])

Policy=np.empty(shape)
Policy.fill(init_prob)
Value_function = np.zeros((4,5),dtype = float)
Value_function,Policy=policy_itr(Policy,Gamma,Value_function)
print(Value_function)
print(Policy)

Policy=np.empty(shape)
Policy.fill(init_prob)
Value_function = np.zeros((4,5),dtype = float)
Value_function,Policy = value_itr(Policy,Gamma,Value_function)
print(Value_function)
print(Policy)
