/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <limits.h>
#include <chrono>

using namespace std;
using namespace Desdemona;
const int MAX = 20000000;
const int MIN = -20000000;
auto start = chrono::steady_clock::now();


class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread.
         */
        MyBot( Turn turn );

        /**
         * Play something
         */
        virtual Move play(const OthelloBoard& board );
        virtual int minimax(OthelloBoard& board, Turn turn, int depth, Move move, int alpha, int beta);
    private:

};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play(const OthelloBoard& board)
{
    start = chrono::steady_clock::now();
    list<Move> moves = board.getValidMoves( turn );
    Move max_move = *moves.begin();
    int best_utility = MIN;
    int maximum_depth = 0;
    while(++maximum_depth){

        for (Move move: moves)
        {
            OthelloBoard newBoard = OthelloBoard(board);
            int evaluated = minimax(newBoard, this->turn, maximum_depth, move, MIN, MAX);

            if(evaluated == MIN){
                return max_move;
            }

            if(evaluated > best_utility){
                max_move = move;
                best_utility = evaluated;
            }


        }
    }
    return max_move;
}

int MyBot::minimax(OthelloBoard& board, Turn turn, int depth, Move move, int alpha, int beta){

    if(( chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - start).count() ) > 1500){
        return MIN;
    }


    OthelloBoard newBoard = OthelloBoard(board);
    newBoard.makeMove(turn, move);
    list<Move> children = newBoard.getValidMoves(other(turn));

    if(depth == 0){
      //heuristic 1
      int parity = 0;
      if(this->turn == BLACK){
        parity = board.getBlackCount() - board.getRedCount();
      }
      else{
        parity =  board.getRedCount() - board.getBlackCount();
      }
      //heuritstic 2
      int myCorners = 0, oppCorners = 0;
      for(int i=0;i<=7;i=i+7){
        for(int j=0;j<=7;j=j+7){
          if(board.get(i,j) == this->turn)
              myCorners ++;
          else if(board.get(i, j) == other(this->turn))
              oppCorners++;
        }
      }
      int corner = myCorners - oppCorners;
      //heuristic 3
      int myMoves = board.getValidMoves(this->turn).size();
      int oppMoves = board.getValidMoves(other(this->turn)).size();
      int mobility = myMoves - oppMoves;

      return corner;
    }

    if(this->turn == turn){ // minimizingPlayer, Note: Convention seems to be interchanged, but, turn updated after making move only
        int best = MAX;
        for (Move child: children)
        {
            int val = minimax(newBoard, other(turn), depth-1, child, alpha, beta);
            best = min(val, best);
            beta = min(best, beta);
            if (beta <= alpha)
                break;
        }
        return best;
    }
    else // maximizing player
    {
        int best = MIN;
        for (Move child: children)
        {
            int val = minimax(newBoard, other(turn), depth-1, child, alpha, beta);
            if(val == MIN){
                return MIN;
            }
            best = max(val, best);
            alpha = max(best, alpha);
            if (beta <= alpha)
                break;
        }
        return best;
    }
}


// The following lines are _very_ important to create a bot module for Desdemona
extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}
