import sys
import random
import copy
import time
import math

class City: #class to represent city
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.distance = None

def next_step_ant(curr_tour,no_of_cities,cities,pheromone,alpha,beta): # find next valid move of ants in probabilistic way
    allowed_moves = [i for i in range(no_of_cities) if i not in curr_tour]
    valid_pheromone = [math.pow(pheromone[curr_tour[-1]][allowed_moves[i]],alpha) for i in range(len(allowed_moves))]
    valid_distances = [math.pow((1 / cities[curr_tour[-1]].distance[i]),beta) for i in allowed_moves]
    valid_product = [valid_pheromone[i] * valid_distances[i] for i in range(len(allowed_moves))]
    valid_prob = [valid_product[i] / sum(valid_product) for i in range(len(allowed_moves))]
    a = random.random()
    i = 0
    s = valid_prob[0]
    while True:
        if s > a:
            return allowed_moves[i]
        i += 1
        s += valid_prob[i]

def ant(no_of_cities,cities,maxiter,pheromone,ants,alpha,beta,q,rho):
    # ant colony optimization
    min = -1
    best_tour = [i for i in range(no_of_cities)] #initial best tour
    iter = 0
    while time.time() < begin + 298 and iter < maxiter: # check for time
        next_pheromone = copy.deepcopy(pheromone) # create a copy of current pheromone
        for i in range(ants): #loop over number of ants
            curr_tour = []
            curr_tour.append(0)
            while len(curr_tour) != no_of_cities: # loop till all cities are not visited
                curr_tour.append(next_step_ant(curr_tour,no_of_cities,cities,pheromone,alpha,beta))
            cost = 0
            for i in range(len(curr_tour)-1):
                cost += cities[curr_tour[i]].distance[curr_tour[i+1]]
            if min == -1:
                min = cost
                best_tour = curr_tour
            elif min > cost: #update best tour if curr tour has less cost
                min = cost
                best_tour = curr_tour
        s = curr_tour
        cost = 0
        for i in range(len(curr_tour)-1): # calculate cost of current tour
            cost += cities[curr_tour[i]].distance[curr_tour[i+1]]
        for i in range(len(curr_tour) - 1): # update next pheromone
            next_pheromone[curr_tour[i]][curr_tour[i + 1]] *= rho
            next_pheromone[curr_tour[i]][curr_tour[i + 1]] += q / cost
            next_pheromone[curr_tour[i + 1]][curr_tour[i]] *= rho
            next_pheromone[curr_tour[i + 1]][curr_tour[i]] += q / cost
        pheromone = next_pheromone
        # get cost
        cost = 0
        for i in range(len(best_tour)-1):
            cost += cities[best_tour[i]].distance[best_tour[i+1]]
        #print the output
        print(cost)
        print(*best_tour, sep=' ')
        print("\n-------------")
        iter += 1
    return best_tour

import time
begin = time.time()

#read input
file = open(sys.argv[1],"r")
is_euc = file.readline().strip()
no_of_cities = int(file.readline().strip())
cities = []
for i in range(no_of_cities):
    x,y = file.readline().strip().split()
    c = City(float(x), float(y))
    cities.append(c)
for city in cities:
    temp = []
    city.distance = list(map(float,file.readline().split()))

#initialize ant colony optimization and run
initial_pheromone_matrix = [[1 / (no_of_cities * no_of_cities) for j in range(no_of_cities)] for i in range(no_of_cities)]
if is_euc=='euclidean':
    tour = ant(no_of_cities=no_of_cities,cities=cities,maxiter=500,pheromone=initial_pheromone_matrix,ants=100,alpha=1.0,beta=10.0,q=1,rho=0.1)
else:
    tour = ant(no_of_cities=no_of_cities,cities=cities,maxiter=500,pheromone=initial_pheromone_matrix,ants=100,alpha=5.0,beta=12.0,q=0.5,rho=0.5)
end = time.time()
#print("Total Time taken in sec:",end - begin)
