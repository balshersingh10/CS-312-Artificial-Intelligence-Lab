command line argument = input file name
./run.sh <input_file_name>


output in output.txt
